import { defineConfig } from 'astro/config';

export default defineConfig({
  site: 'https://ailib.rs',
  output: 'static'
});